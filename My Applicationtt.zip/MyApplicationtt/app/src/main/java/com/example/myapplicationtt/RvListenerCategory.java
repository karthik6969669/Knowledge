package com.example.myapplicationtt;

import com.example.myapplicationtt.models.ModelCategory;

public interface RvListenerCategory {

    void onCategoryClick(ModelCategory modelCategory);
}
